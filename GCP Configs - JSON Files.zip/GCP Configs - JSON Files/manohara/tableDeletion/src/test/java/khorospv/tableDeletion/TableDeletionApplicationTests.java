package khorospv.tableDeletion;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TableDeletionApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
