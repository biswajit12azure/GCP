package khorospv.tableDeletion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class TableDeletionApplication {

	public static void main(String[] args) {
		SpringApplication.run(TableDeletionApplication.class, args);
	}

}
