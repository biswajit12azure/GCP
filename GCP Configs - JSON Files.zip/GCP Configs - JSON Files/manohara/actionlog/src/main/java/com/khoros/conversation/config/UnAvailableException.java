package com.khoros.conversation.config;

public class UnAvailableException extends Exception {

    public UnAvailableException() {
        super();
    }

    public UnAvailableException(String message) {
        super(message);
    }
}
