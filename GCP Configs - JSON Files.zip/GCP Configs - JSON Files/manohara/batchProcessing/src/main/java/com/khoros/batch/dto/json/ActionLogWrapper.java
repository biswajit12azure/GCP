package com.khoros.batch.dto.json;

import lombok.Data;

@Data
public class ActionLogWrapper {

}
